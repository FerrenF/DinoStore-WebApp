
function debug_message(message, level){
    console.log(message)
}

function graceful_shutdown(code, message){

}

module.exports = {debug_message, graceful_shutdown}