export const APP_PORT = 3050
export const API_PORT = 3051
export const DEBUG_MODE = "ERROR"
export const COOKIE_SAVE_TIME_DAYS = 30;