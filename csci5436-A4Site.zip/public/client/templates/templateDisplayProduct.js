import {Product} from "../model/product.js";

import {debugMessage} from "../common.js";

export function init_template(context) {
    return Promise.resolve({"status":"success"})
}
